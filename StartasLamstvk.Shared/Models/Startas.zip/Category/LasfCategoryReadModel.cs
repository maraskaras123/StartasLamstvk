﻿using StartasLamstvk.Shared.Models.Enum;

namespace StartasLamstvk.Shared.Models.Category
{
    public class LasfCategoryReadModel
    {
        public EnumLasfCategory Id { get; set; }
        public string Title { get; set; }
    }
}
