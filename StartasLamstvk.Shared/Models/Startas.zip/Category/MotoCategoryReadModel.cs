﻿using StartasLamstvk.Shared.Models.Enum;

namespace StartasLamstvk.Shared.Models.Category
{
    public class MotoCategoryReadModel
    {
        public EnumMotoCategory Id { get; set; }
        public string Title { get; set; }
    }
}