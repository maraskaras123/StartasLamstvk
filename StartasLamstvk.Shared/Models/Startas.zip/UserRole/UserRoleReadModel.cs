﻿using StartasLamstvk.Shared.Models.Enum;

namespace StartasLamstvk.Shared.Models.UserRole
{
    public class UserRoleReadModel
    {
        public EnumRole Id { get; set; }
        public string Name { get; set; }
    }
}
