﻿namespace StartasLamstvk.Shared.Models.RacePreference
{
    public class RacePreferenceReadModel
    {
        public int EventId { get; set; }
        public string Title { get; set; }
    }
}