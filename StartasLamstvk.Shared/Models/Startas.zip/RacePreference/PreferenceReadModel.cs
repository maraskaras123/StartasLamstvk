﻿using StartasLamstvk.Shared.Models.Enum;

namespace StartasLamstvk.Shared.Models.RacePreference
{
    public class PreferenceReadModel
    {
        public EnumRaceType RaceTypeId { get; set; }
        public string Title { get; set; }
    }
}