﻿using StartasLamstvk.Shared.Models.Enum;

namespace StartasLamstvk.Shared.Models.RaceType
{
    public class RaceTypeReadModel
    {
        public EnumRaceType RaceTypeId { get; set; }
        public string Title { get; set; }
    }
}