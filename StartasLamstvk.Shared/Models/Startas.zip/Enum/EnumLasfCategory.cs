﻿namespace StartasLamstvk.Shared.Models.Enum
{
    public enum EnumLasfCategory
    {
        Intern = 1,
        Third = 2,
        Second = 3,
        First = 4,
        National = 5,
        International = 6
    }
}