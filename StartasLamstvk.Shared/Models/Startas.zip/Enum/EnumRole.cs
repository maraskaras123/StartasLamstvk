﻿namespace StartasLamstvk.Shared.Models.Enum
{
    public enum EnumRole
    {
        Admin = 1,
        Director = 2,
        Marshal = 3
    }
}