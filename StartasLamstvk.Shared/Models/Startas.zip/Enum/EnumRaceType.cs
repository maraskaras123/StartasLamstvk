﻿namespace StartasLamstvk.Shared.Models.Enum
{
    public enum EnumRaceType
    {
        Rally = 1,
        Kart = 2,
        AutoCircuit = 3,
        MotoCircuit = 4,
        MotoCross = 5,
        AutoCross = 6,
        Drift = 7,
        Slalom = 8,
        SuperMoto = 9,
        HardEnduro = 10
    }
}